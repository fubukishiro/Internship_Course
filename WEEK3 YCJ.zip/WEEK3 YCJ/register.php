<html>
<body>
Your username is: <?php echo $_POST["username"]; ?><br>
Your password is: <?php echo $_POST["password"]; ?><br>
</body>
</html>

<?php
$con = mysql_connect("127.0.0.1","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("yingchengjun", $con);

$sql="INSERT INTO user (username,password)
VALUES
('$_POST[username]','$_POST[password]')";

if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

mysql_close($con)
?>